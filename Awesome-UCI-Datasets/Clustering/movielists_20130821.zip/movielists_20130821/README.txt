Movie Lists Dataset
Version: 2013-08-21
---------------------------------------------
This archive contains the data used in the paper "Discovering Latent Patterns from the Analysis of User-Curated Movie Lists". D. Greene, P. Cunningham (2013). 

For a PDF pre-print version, see:
http://arxiv.org/abs/1308.5125

For more details contact derek.greene@ucd.ie or visit http://mlg.ucd.ie/movielists - if you find the data useful, we would encourage you to cite the above paper.

The data was collected from the Internet Movie Database (IMDb) in July 2013, and covers on a total of approximately 120k IMDb lists, curated by 44k distinct users, and lists over 249k movies. The datasets are made available for further non-commercial and research purposes only. They are provided in pre-processed matrix format only, and we do not include the original raw lists.

The archive contains two weighted undirected graphs in GraphML format (http://graphml.graphdrawing.org/):
1. imdb-colisted.graphml: Complete co-listed graph, with no normalisation. Each node corresponds to a movie. An edge exists between two movies if they are assigned to one or more lists together. The weight on each edge indicates the number of lists that they share.
2. imdb-normalised.graphml: Normalised co-listed graph, thresholded at 0.1. This graph was used in the analysis described in our paper.

In both graphs, movie nodes are identified by their unique IMDb IDs ttXXXXXXX (e.g. tt1375666 = "Inception"). Each node also has a "title" attribute, indicating the movie's title.

